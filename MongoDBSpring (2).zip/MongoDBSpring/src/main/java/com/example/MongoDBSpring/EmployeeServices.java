package com.example.MongoDBSpring;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeServices {
	
	@Autowired
	DbServices service;
	
	@PostMapping("/insert/{id}")
	public String insert(@RequestBody Employee e)
	{
		service.save(e);
		return "Succesfully inserted";
	}

	@GetMapping(value="/select/{id}",produces=MediaType.APPLICATION_JSON_VALUE)
	public Optional<Employee> findById(@PathVariable("id")long id)
	{
		return service.findById(id);
	}
	@PostMapping("/update/{id}")
    public String insert3(@PathVariable("id")long id,@RequestBody Employee e){
        Optional<Employee> em=service.findById(id);
        if(em.isPresent())
        {
            System.out.println("ID Exists");
            service.save(e);
            System.out.println("Data Updated");
            System.out.println(e);
        }
        else
        {
            System.out.println("Invalid id");
        }
    
        return "Update Success";
    }
    @DeleteMapping("/delete/{id}")
    public String insert4(@PathVariable("id")long id){
        Optional<Employee> em=service.findById(id);
        if(em.isPresent())
        {
            System.out.println("ID Exists");
            service.deleteById(id);
            System.out.println("Data deleted");
        }
        else
        {
            System.out.println("Invalid id");
        }
    
        return "Delete Success";
    }
    @GetMapping("/byname/{name}")
    public ArrayList<Employee> findByName(@PathVariable("name")String name)
    {
    	return service.findByName(name);
    	
    }
    @GetMapping("/byage/{age}")
    public ArrayList<Employee> findByAge(@PathVariable("age")int age)
    {
    	return service.findByAge(age);
    }

}
