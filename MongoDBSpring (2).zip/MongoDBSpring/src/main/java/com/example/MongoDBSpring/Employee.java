package com.example.MongoDBSpring;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="test")
public class Employee {
		@Id  
		private Long id;
		private int age;
		private String name;
		private int salary;
		public Employee(Long id, int age, String name, int salary) {
			super();
			this.id = id;
			this.age = age;
			this.name = name;
			this.salary = salary;
		}
		public long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Employee() {
			super();
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}
}
