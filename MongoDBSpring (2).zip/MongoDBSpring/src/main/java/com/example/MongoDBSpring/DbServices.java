package com.example.MongoDBSpring;

import java.util.ArrayList;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface DbServices extends MongoRepository<Employee, Long> {
		ArrayList<Employee> findByName(String name);
		ArrayList<Employee> findByAge(int age);
}
